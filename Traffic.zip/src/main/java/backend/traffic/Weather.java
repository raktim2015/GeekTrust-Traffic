
import java.util.ArrayList;
interface Weather
{
    
    double getCrater_percent_change();
    ArrayList <Vehicle> getVehicles();
}