interface Orbit
{
    public double getDistance();
    public double getCraters();
    public double getTraffic_speed();
    public String getOrbit_name();
}