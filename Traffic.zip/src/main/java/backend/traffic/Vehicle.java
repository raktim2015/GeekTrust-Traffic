interface Vehicle
{
    public double getSpeed();
    public double getTime_to_cross_a_crater();
    public String getVehicle_name();
}